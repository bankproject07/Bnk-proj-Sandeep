package com.cg.obs.junittest;
import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.obs.bean.Admin;

public class TestAdmin {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testAdminStringString() {
		Admin admin= new Admin("admin","admin");
		assertEquals("admin","admin");
		
	}

	@Test
	public void testGetAdminid() 
	{
		Admin admin = new Admin("admin","admin");
		assertEquals(admin.getAdminid(), "admin");
	}

	@Test
	public void testGetAdminPassword() 
	{
		Admin admin = new Admin("admin","admin");
		assertEquals(admin.getAdminPassword(), "admin");
	}

}
